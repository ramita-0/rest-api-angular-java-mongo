package com.example.demo;

public class Alumno {

        /** completar **/

    public Alumno(String nombre, int edad) {
        /** completar **/
    }
}
