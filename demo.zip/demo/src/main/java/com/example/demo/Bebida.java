package com.example.demo;

public class Bebida {
    private int graduacion;
    private String nombre;

    public Bebida(int graduacion, String nombre) {
        this.graduacion = graduacion;
        this.nombre = nombre;
    }
}
